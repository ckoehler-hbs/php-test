<!-- Chapter 2, Exercise 2-5
Coast City Computers Header -->

<hr/>
<table width="100%" style="border: 0;">
	<tr>
		<td><strong>Updated:</strong>April 22, 2025</td>
		<td style="text-align: right;">
			<?php
			 	$year = date("Y");
			 	echo "&copy;$year by Coast City Computers";
			?>
		</td>
	</tr>
</table>