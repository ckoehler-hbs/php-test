<!-- Chapter 2, Exercise 2-5
Coast City Computers Header -->

<table width="100%" style="border: 0;">
	<tr>
		<td><h1 style="font-family: 'Georgia';">Coast City Computers</h1></td>
		<td style="text-align: right;"><h3>Buy Online or Call: 1-800-555-1212</h3></td>
	</tr>
</table>
<hr/>